clipRange <- function(x, min=0, max=1) {
  x <- apply(x, 2, function(xx) pmax(xx, min))
  x <- apply(x, 2, function(xx) pmin(xx, max))
}
