getReference <- function(data, idx, na.rm=TRUE) {
  data.frame(sapply(idx, function(x) rowMeans(data[,x], na.rm=na.rm)))
}

getF <- function(prop, profile, subject, onlyF=FALSE) {
  virtualMix <- profile[,1]*prop + profile[,2]*(1-prop)
  fit <- summary(lm(subject ~ virtualMix))
  slope <- fit$coefficients["virtualMix", "Estimate"]
  f <- as.vector(fit$fstatistic["value"])
  signedF <- f * sign(slope)
  if (onlyF) {
    return(signedF)
  } else {
    sigma <- fit$sigma
    return(c(signedF=signedF, slope=slope, sigma=sigma, p=pf(f, fit$fstatistic["numdf"], fit$fstatistic["dendf"], lower.tail=FALSE)))
  }
}


estProportion <- function(data, profile, resolution=0.0001, detail=FALSE, matchFeatures=TRUE) {
  # Match features between data and profile
  if (matchFeatures) {
    common <- intersect(rownames(data), rownames(profile))
    data <- data[match(common, rownames(data)), ]
    profile <- profile[match(common, rownames(profile)), ]
  }
  prop <- apply(as.matrix(data), 2, function(subject) { 
    optimize(getF, interval=c(0,1), maximum=TRUE, tol=resolution, profile=profile, subject=subject, onlyF=TRUE)$maximum
  })
  if (!detail) {
    prop
  } else {
    t(sapply(1:ncol(data), function(i) {
      c(prop=as.vector(prop[i]), getF(prop[i],  profile=profile, subject=data[,i], onlyF=FALSE))
    }))
  }
}


xform <- function(data, modelData, modelIdx, reference="neuron", prop, p=0.05) {
  refProfile <- getReference(modelData, modelIdx)
  d <- refProfile[,1] - refProfile[,2]
  x <- as.matrix(d) %*% prop
  # Subset to p<0.05 differences
  n <- sapply(modelIdx, sum) 
  class <- factor(rep(names(n), n))
  dat <-   do.call("cbind", lapply(modelIdx, function(x) modelData[,x]))
  tp <- rowttests(as.matrix(dat), class)$p.value
  sig <- tp<p
  if (reference=="neuron") {
    data[sig,] <- (data + as.matrix(d) %*% (1-prop))[sig,] 
  } else if (reference=="glia") {
    data[sig,] <- (data - as.matrix(d) %*% prop)[sig,]
  } else {
    stop("Only neuron and glia reference profiles are currently supported")
  }
  return(data)
}
